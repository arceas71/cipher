#!/usr/bin/env python3
"""
J.A.R.V.I.S. Autonomous AI Brain & Tool Execution Engine
Powered by Free GitHub Models API (models.inference.ai.azure.com)
"""

import json
import os
import subprocess
import sys
import urllib.request
import urllib.error

ENDPOINT = "https://models.inference.ai.azure.com/chat/completions"
TOKEN = os.environ.get("GITHUB_TOKEN", "")
MODEL = os.environ.get("JARVIS_MODEL", "gpt-4o-mini")
PROMPT = os.environ.get("JARVIS_PROMPT", "Summarize repository files and system status.")
SUMMARY_FILE = os.environ.get("GITHUB_STEP_SUMMARY", "")

# --- Feature 4: The Hands (Safe Autonomous Repository Tools) ---

def list_repo_files(directory=".") -> str:
    results = []
    for root, dirs, files in os.walk(directory):
        dirs[:] = [d for d in dirs if not d.startswith(".git") and d != "node_modules"]
        for file in files:
            results.append(os.path.relpath(os.path.join(root, file), directory))
    return "\n".join(sorted(results)[:100])

def read_file(filepath: str) -> str:
    safe_path = os.path.abspath(filepath)
    if not safe_path.startswith(os.getcwd()):
        return "Error: Access outside workspace denied."
    if not os.path.exists(safe_path):
        return f"Error: File {filepath} does not exist."
    with open(safe_path, "r", encoding="utf-8", errors="replace") as f:
        return f.read()[:6000]

def write_file(filepath: str, content: str) -> str:
    safe_path = os.path.abspath(filepath)
    if not safe_path.startswith(os.getcwd()):
        return "Error: Access outside workspace denied."
    os.makedirs(os.path.dirname(safe_path) or ".", exist_ok=True)
    with open(safe_path, "w", encoding="utf-8") as f:
        f.write(content)
    return f"Successfully wrote {len(content)} bytes to {filepath}"

def run_python_check(command: str) -> str:
    try:
        proc = subprocess.run(
            command,
            shell=True,
            capture_output=True,
            text=True,
            timeout=20
        )
        out = (proc.stdout + "\n" + proc.stderr).strip()
        return out[:3000] if out else f"Command exited with {proc.returncode}"
    except Exception as exc:
        return f"Execution error: {exc}"

TOOLS_SPEC = [
    {
        "type": "function",
        "function": {
            "name": "list_repo_files",
            "description": "List files in the GitHub repository workspace.",
            "parameters": {"type": "object", "properties": {}, "required": []}
        }
    },
    {
        "type": "function",
        "function": {
            "name": "read_file",
            "description": "Read the contents of a repository file.",
            "parameters": {
                "type": "object",
                "properties": {"filepath": {"type": "string"}},
                "required": ["filepath"]
            }
        }
    },
    {
        "type": "function",
        "function": {
            "name": "write_file",
            "description": "Create or update a file in the repository.",
            "parameters": {
                "type": "object",
                "properties": {
                    "filepath": {"type": "string"},
                    "content": {"type": "string"}
                },
                "required": ["filepath", "content"]
            }
        }
    }
]

# --- Feature 2: The Brain (GitHub Models API Client) ---

def call_github_models(messages):
    if not TOKEN:
        return None
    payload = {
        "model": MODEL,
        "messages": messages,
        "tools": TOOLS_SPEC,
        "temperature": 0.2
    }
    req = urllib.request.Request(
        ENDPOINT,
        data=json.dumps(payload).encode("utf-8"),
        headers={
            "Content-Type": "application/json",
            "Authorization": f"Bearer {TOKEN}"
        },
        method="POST"
    )
    try:
        with urllib.request.urlopen(req, timeout=45) as resp:
            return json.loads(resp.read().decode("utf-8"))
    except urllib.error.HTTPError as err:
        print(f"[JARVIS] GitHub Models HTTP {err.code}: {err.read().decode('utf-8', 'ignore')}")
        return None
    except Exception as exc:
        print(f"[JARVIS] GitHub Models request error: {exc}")
        return None

def execute_agent():
    print(f"=== J.A.R.V.I.S. Autonomous Engine ({MODEL}) ===")
    print(f"Directive: {PROMPT}")
    files_snapshot = list_repo_files()

    messages = [
        {
            "role": "system",
            "content": (
                "You are J.A.R.V.I.S., a sophisticated autonomous engineering system "
                "operating inside a GitHub Actions runner. Use your tools to inspect or update "
                "files as requested, and deliver a sharp, well-structured Markdown report."
            )
        },
        {
            "role": "user",
            "content": f"Directive: {PROMPT}\n\nCurrent Repository Files:\n{files_snapshot}"
        }
    ]

    tool_log = []
    final_answer = None

    for step in range(4):
        response = call_github_models(messages)
        if not response or "choices" not in response:
            break
        choice = response["choices"][0]["message"]
        messages.append(choice)

        tool_calls = choice.get("tool_calls")
        if not tool_calls:
            final_answer = choice.get("content", "")
            break

        for tc in tool_calls:
            fn_name = tc["function"]["name"]
            args = json.loads(tc["function"].get("arguments", "{}"))
            if fn_name == "list_repo_files":
                result = list_repo_files()
            elif fn_name == "read_file":
                result = read_file(args.get("filepath", "README.md"))
            elif fn_name == "write_file":
                result = write_file(args.get("filepath", "output.md"), args.get("content", ""))
            else:
                result = "Unknown tool"

            tool_log.append(f"- Executed `{fn_name}({json.dumps(args)})`")
            messages.append({
                "role": "tool",
                "tool_call_id": tc["id"],
                "content": result
            })

    if not final_answer:
        final_answer = (
            f"### Autonomous Workspace Audit Complete\n\n"
            f"- **Directive Processed**: `{PROMPT}`\n"
            f"- **Indexed Files**:\n```\n{files_snapshot}\n```"
        )

    report_md = (
        f"# 🟣 J.A.R.V.I.S. Execution Report\n\n"
        f"- **Brain Model**: `{MODEL}` (GitHub Models API)\n"
        f"- **Directive**: {PROMPT}\n\n"
    )
    if tool_log:
        report_md += "## ⚙ Tool Actions Executed\n" + "\n".join(tool_log) + "\n\n"
    report_md += "## 📋 Output Summary\n" + final_answer + "\n"

    print(report_md)
    if SUMMARY_FILE:
        with open(SUMMARY_FILE, "a", encoding="utf-8") as sf:
            sf.write(report_md)

if __name__ == "__main__":
    execute_agent()
